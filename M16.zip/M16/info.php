<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <script src="https://cdn.tailwindcss.com"></script>

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

</head>
<body>

    <header class="bg-green-700 text-white">
    <div class="max-w-7xl mx-auto py-6">
      <h1 class="text-2xl font-bold flex justify-center">E-Lixo Zero Lisboa</h1>
      <?php if (isset($_SESSION['user_id'])): ?>
        <div class="user-info">
            👤 <?= htmlspecialchars($_SESSION['nome'] ?? 'Utilizador') ?> 
            <small>(<?= htmlspecialchars($_SESSION['role'] ?? '') ?>)</small>
            <a href="logout.php">Sair</a>
        </div>
      <?php endif; ?>
      <nav class="space-x-6 py-6 text-sm flex justify-center">
        <a href="mapa.html" class="hover:underline">Pontos de recolha</a>
        <a href="#reciclar" class="hover:underline">Como Reciclar</a>
        <a href="#impacto" class="hover:underline">Impacto</a>
        <a href="#contacto" class="hover:underline">Contacto</a>
        <a href="info.php" class="hover:underline">O que é o lixo eletrónico?</a>
        <?php if (!isset($_SESSION['user_id'])): ?>
          <a href="login.php" class="hover:underline">Login</a>
          <a href="registar.php" class="hover:underline">Registrar</a>
        <?php endif; ?>
      </nav>
    </div>
  </header>
    
</body>
</html>