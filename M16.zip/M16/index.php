<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-PT">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>E-Lixo Zero Lisboa</title>

  <script src="https://cdn.tailwindcss.com"></script> 

  <style>
    body {
      font-family: 'Inter', sans-serif;
    }

    .hero-bg {
      background: linear-gradient(to right, rgba(16,185,129,0.9), rgba(5,150,105,0.9)),
      url('https://bordalo.observador.pt/v2/q:75/c:770:433:nowe:0:0/rs:fill:860/f:webp/plain/https://s3.observador.pt/wp-content/uploads/2015/09/152303680_770x433_acf_cropped.jpg');
      background-size: cover;
      background-position: center;
    }

    .card-hover:hover {
      transform: translateY(-6px);
      transition: 0.3s ease;
      box-shadow: 0 20px 40px rgba(0,0,0,0.08);
    }
  </style>

</head>

<body class="bg-gray-50 text-gray-800">

  <!-- NAVBAR -->
  <header class="bg-white/80 backdrop-blur-md shadow-sm fixed w-full z-50">
    <div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
      
      <h1 class="text-xl font-bold text-green-700 tracking-tight">
        E-Lixo Zero <span class="text-gray-800">Lisboa</span>
      </h1>

      <nav class="hidden md:flex space-x-8 text-sm font-medium">
        <a href="mapa.html" class="hover:text-green-700 transition">Pontos</a>
        <a href="#reciclar" class="hover:text-green-700 transition">Como Reciclar</a>
        <a href="#impacto" class="hover:text-green-700 transition">Impacto</a>
        <a href="info.php" class="hover:text-green-700 transition">Sobre</a>

        <?php if (!isset($_SESSION['user_id'])): ?>
          <a href="login.php" class="text-gray-600 hover:text-green-700 transition">Login</a>
          <a href="registar.php" class="bg-green-700 text-white px-4 py-2 rounded-lg hover:bg-green-800 transition">Criar Conta</a>
        <?php else: ?>
          <span class="text-gray-600">
            <?= htmlspecialchars($_SESSION['nome'] ?? 'Utilizador') ?>
          </span>
          <a href="logout.php" class="text-red-500 hover:underline">Sair</a>
        <?php endif; ?>
      </nav>
    </div>
  </header>

  <!-- HERO -->
  <section class="hero-bg text-white pt-40 pb-28">
    <div class="max-w-5xl mx-auto text-center px-6">
      <h2 class="text-5xl font-bold leading-tight mb-6">
        Reciclar tecnologia é proteger o futuro de Lisboa
      </h2>
      <p class="text-lg text-green-100 mb-8 max-w-2xl mx-auto">
        Descobre onde entregar os teus equipamentos eletrónicos e contribui para uma cidade mais sustentável.
      </p>
      <a href="mapa.html"
         class="bg-white text-green-700 px-8 py-4 rounded-xl font-semibold shadow-lg hover:scale-105 transition">
        Ver Pontos de Recolha
      </a>
    </div>
  </section>

  <!-- COMO RECICLAR -->
  <section id="reciclar" class="py-20 bg-gray-50">
    <div class="max-w-7xl mx-auto px-6">
      <h3 class="text-3xl font-bold text-center mb-14">Como reciclar corretamente</h3>

      <div class="grid md:grid-cols-3 gap-10">
        
        <div class="bg-white p-8 rounded-2xl shadow-sm card-hover">
          <h4 class="font-bold text-lg mb-3 text-green-700">Pequenos equipamentos</h4>
          <p class="text-gray-600 text-sm leading-relaxed">
            Telemóveis, carregadores e rádios devem ser entregues em Pontos Eletrão ou superfícies comerciais aderentes.
          </p>
        </div>

        <div class="bg-white p-8 rounded-2xl shadow-sm card-hover">
          <h4 class="font-bold text-lg mb-3 text-green-700">Equipamento informático</h4>
          <p class="text-gray-600 text-sm leading-relaxed">
            Computadores e impressoras contêm metais valiosos e componentes perigosos que devem ser reciclados corretamente.
          </p>
        </div>

        <div class="bg-white p-8 rounded-2xl shadow-sm card-hover">
          <h4 class="font-bold text-lg mb-3 text-green-700">Grandes eletrodomésticos</h4>
          <p class="text-gray-600 text-sm leading-relaxed">
            A Câmara Municipal disponibiliza recolha gratuita mediante pedido para frigoríficos, máquinas e outros equipamentos.
          </p>
        </div>

      </div>
    </div>
  </section>

  <!-- IMPACTO -->
  <section id="impacto" class="py-20 bg-white">
    <div class="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-16 items-center">
      
      <div>
        <h3 class="text-3xl font-bold mb-6">Porque é mesmo importante reciclar</h3>
        <p class="text-gray-600 leading-relaxed mb-6">
          O lixo eletrónico contém substâncias tóxicas que podem contaminar solos e águas. 
          Ao reciclar, recuperamos matérias-primas e reduzimos a necessidade de nova extração.
        </p>

        <ul class="space-y-3 text-gray-700">
          <li>🌱 Proteção ambiental</li>
          <li>⚕️ Menos riscos para a saúde pública</li>
          <li>🔄 Promoção da economia circular</li>
        </ul>
      </div>

      <div class="bg-green-700 text-white p-10 rounded-3xl shadow-xl">
        <h4 class="text-xl font-semibold mb-4">Sabias que?</h4>
        <p class="text-green-100">
          Muitos equipamentos eletrónicos contêm ouro, cobre e alumínio que podem ser reutilizados.
          Reciclar é transformar desperdício em recurso.
        </p>
      </div>

    </div>
  </section>

  <!-- FOOTER -->
  <footer class="bg-gray-900 text-gray-400 py-10">
    <div class="max-w-7xl mx-auto px-6 text-center">
      <p class="text-sm">
        Projeto <span class="text-white font-medium">E-Lixo Zero Lisboa</span>  
        • EPBJC • 2025/2026
      </p>
      <p class="text-xs mt-3 text-gray-500">
        Desenvolvido com foco na sustentabilidade e responsabilidade ambiental.
      </p>
    </div>
  </footer>

</body>
</html>