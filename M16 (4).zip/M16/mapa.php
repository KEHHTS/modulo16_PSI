

<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mapa Lisboa</title>
    
    <!-- CSS do Leaflet -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>


    <script src="https://cdn.tailwindcss.com"></script>


    
    <style>
        #map { height: calc(100vh - 5.9rem); width: 100%; } 

        header { background-color: #C1E3D9;}

        #search-container {
            background-color: #C1E3D9;
            padding: 5px;
        }
        button {
            padding: 10px;
            font-size: 16px;
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
  <header>
    <div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center"> 
    <h1 class="text-xl font-bold text-green-700 tracking-tight">
        E-Lixo Zero <span class="text-gray-800">Lisboa</span>
      </h1>
    <nav class="space-x-6 text-sm">
        <a href="index.php" class="hover:underline">Inicio</a>
    </nav>
    </div>
  </header>

    <div id="search-container">
        <input type="text" id="search" placeholder="Digite um local...">
        <button onclick="searchLocation()">🔎</button>
    </div>

    <div id="map"></div>

    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

    <script>
        // Criando o mapa e definindo um ponto inicial
        var map = L.map('map').setView([38.727549, -9.133379], 11.5); // Ponto inicial Lisboa

        // Adicionando camada de mapa OpenStreetMap
        var baseLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        var redIcon = new L.Icon({
            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
            shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',

            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        var greenIcon = new L.Icon({
            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/refs/heads/master/img/marker-icon-green.png',
            shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',

            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        var marker = L.marker([38.708018, -9.140109], { icon: redIcon }).addTo(map);
        marker.bindPopup("Você está aqui!");

        var GeoJSONLayer = L.layerGroup();
        var REEELayer = L.layerGroup();
        var pilhoesLayer = L.layerGroup();

        fetch('get_pontos.php')
    .then(res => res.json())
    .then(dados => {

        dados.forEach(ponto => {

            L.marker([
                ponto.latitude,
                ponto.longitude
            ])
            .addTo(map)
            .bindPopup(
                ponto.tprs_desc + "<br>" +
                ponto.freguesia + "<br>" +
                ponto.rua
            );

        });

    });

        // Função para buscar a localização digitada
        function searchLocation() {
            var query = document.getElementById("search").value;
            if (query) {
                fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${query}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.length > 0) {
                            var lat = data[0].lat;
                            var lon = data[0].lon;

                            // Movendo o mapa para a nova localização
                            map.setView([lat, lon], 13);

                            // Atualizando o marcador
                            marker.setLatLng([lat, lon])
                                  .bindPopup(`<b>${query}</b>`)
                                  .openPopup();
                        } else {
                            alert("Local não encontrado. Tente novamente.");
                        }
                    })
                    .catch(error => console.error("Erro na busca:", error));
            } else {
                alert("Digite um local para buscar.");
            }
        }

        // Função para gerar uma cor aleatória
        function getRandomColor() {
            return "#" + Math.floor(Math.random()*16777215).toString(16);
        }

        // Adicionando a camada GeoJSON do ArcGIS ao mapa com cores diferentes
        function loadGeoJSON() {
            fetch("https://services.arcgis.com/1dSrzEWVQn5kHHyK/arcgis/rest/services/Limite_Cartografia/FeatureServer/0/query?outFields=*&where=1%3D1&f=geojson")
                .then(response => response.json())
                .then(data => {
                    L.geoJSON(data, {
                        style: function(feature) {
                            return {
                                color: getRandomColor(),  // Gera uma cor diferente para cada feature
                                weight: 2,
                                opacity: 0.8
                            };
                        },
                        onEachFeature: function (feature, layer) {
                            if (feature.properties) {
                                layer.bindPopup(`<b>Área:</b> ${feature.properties.NOME || "Desconhecido"}`);
                            }
                        }
                    }).addTo(GeoJSONLayer);
                })
                .catch(error => console.error("Erro ao carregar GeoJSON:", error));
        }

        function loadREEE() {
            fetch("https://services.arcgis.com/1dSrzEWVQn5kHHyK/arcgis/rest/services/Amb_Reciclagem/FeatureServer/5/query?outFields=*&where=1%3D1&f=geojson")
                .then(response => response.json())
                .then(data => {
                    L.geoJSON(data, {
                        onEachFeature: function (feature, layer) {
                            layer.bindPopup(`<b>Ecoponto:</b> ${feature.properties.PRSL_LOCAL || "Desconhecido"}`);
                        }
                    }).addTo(REEELayer);
                })
                .catch(error => console.error("Erro ao carregar REEE:", error));
        }

        function loadPilhoes() {
            fetch("https://services.arcgis.com/1dSrzEWVQn5kHHyK/arcgis/rest/services/Amb_Reciclagem/FeatureServer/9/query?outFields=*&where=1%3D1&f=geojson")
                .then(response => response.json())
                .then(data => {
                    L.geoJSON(data, {

                        pointToLayer: function (feature, latlng) {
                        return L.marker(latlng, { icon: greenIcon });
                        },

                        onEachFeature: function (feature, layer) {
                            layer.bindPopup(`<b>Ecoponto:</b> ${feature.properties.PRSL_LOCAL || "Desconhecido"}`);
                        }
                    }).addTo(pilhoesLayer);
                })
                .catch(error => console.error("Erro ao carregar Pilhão:", error));
        }

        loadGeoJSON();
        loadREEE();
        loadPilhoes();


        const baseMaps = {
            "OpenStreetMap": baseLayer
        };

        var overlayMaps = {
            "REEE": REEELayer,
            "Pilhões": pilhoesLayer
        };

        L.control.layers(baseMaps, overlayMaps).addTo(map);
    </script>

</body>
</html>
