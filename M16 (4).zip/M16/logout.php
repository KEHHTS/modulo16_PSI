<?php
session_start();

session_unset();

session_destroy();

if (isset($_COOKIE['usuario_logado'])) {
    setcookie("usuario_logado", "", time() - 3600, "/");
}

header("Location: login.php");
exit;

session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}
?>