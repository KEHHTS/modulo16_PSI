<?php
require "connectdb.php";

$erro = "";
$sucesso = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $tipo = $_POST['tipo'];

    if (!$nome || !$email || !$senha || !$tipo) {
        $erro = "Preencha os campos obrigatórios";
    } else {

        $check = $pdo->prepare("SELECT id FROM utilizador WHERE email = :email");
        $check->execute([':email' => $email]);

        if ($check->rowCount() > 0) {
            $erro = "Email já registado";
        } else {

            $hash = password_hash($senha, PASSWORD_DEFAULT);

            $stmt = $pdo->prepare(
                "INSERT INTO utilizador (nome, email, senha, tipo) 
                VALUES 
                (:nome, :email, :senha, :tipo)
            ");

            $stmt->execute([
                ':nome' => $nome,
                ':email' => $email,
                ':senha' => $hash,
                ':tipo' => $tipo
            ]);

            $sucesso = "Utilizador registado com sucesso";

            // 🔥 ENVIAR EMAIL COM PYTHON

            // proteger os dados
            $nome_safe = escapeshellarg($nome);
            $email_safe = escapeshellarg($email);

            // caminho do script Python (ajusta se necessário)
            $comando = "python3 enviar_email.py $nome_safe $email_safe";

            // executar
            exec($comando);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        header { background-color: #C1E3D9;}
    </style>
</head>

<body>

<header>
    <div class="max-w-7xl mx-auto px-6 py-6 flex justify-between items-center"> 
        <h1 class="text-xl font-bold text-green-700 tracking-tight">
            E-Lixo Zero <span class="text-gray-800">Lisboa</span>
        </h1>
        <nav class="space-x-6 text-sm">
            <a href="index.php" class="hover:underline">Inicio</a>
        </nav>
    </div>
</header>

<section class="bg-white py-16">
    <div class="max-w-md mx-auto px-6">
        
        <h3 class="text-3xl font-bold mb-8 text-center">Criar Conta</h3>

        <!-- Mensagens -->
        <?php if ($erro): ?>
            <p class="text-red-600 text-center mb-4"><?= $erro ?></p>
        <?php endif; ?>

        <?php if ($sucesso): ?>
            <p class="text-green-600 text-center mb-4"><?= $sucesso ?></p>
        <?php endif; ?>

        <form method="post" action="" class="space-y-5">

            <!-- Nome -->
            <div>
                <label class="block text-sm font-medium mb-1">Nome</label>
                <input name="nome" type="text" required
                    class="w-full border p-3 rounded-lg" />
            </div>

            <!-- Email -->
            <div>
                <label class="block text-sm font-medium mb-1">Email</label>
                <input name="email" type="email" required
                    class="w-full border p-3 rounded-lg" />
            </div>

            <!-- Senha -->
            <div>
                <label class="block text-sm font-medium mb-1">Palavra-passe</label>
                <input name="senha" type="password" minlength="6" required
                    class="w-full border p-3 rounded-lg" />
            </div>

            <!-- Tipo -->
            <div>
                <label class="block text-sm font-medium mb-1">Tipo de conta</label>
                <select name="tipo" required class="w-full border p-3 rounded-lg">
                    <option value="">Selecione</option>
                    <option value="utilizador">Utilizador</option>
                    <option value="admin">Administrador</option>
                </select>
            </div>

            <button type="submit"
                class="w-full bg-green-700 text-white py-3 rounded-lg">
                Criar Conta
            </button>

        </form>
    </div>
</section>

</body>
</html>