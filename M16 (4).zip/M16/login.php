<?php
session_start();
require "connectdb.php";

$erro = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $stmt = $pdo->prepare("
        SELECT id, nome, email, senha, tipo
        FROM utilizador
        WHERE email = :email
        LIMIT 1
    ");

    $stmt->execute([
        ':email' => $email
    ]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($senha, $user['senha'])) {

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['nome'] = $user['nome'];
        $_SESSION['tipo'] = $user['tipo'];

        if ($user['tipo'] === 'admin') {
            header("Location: index.php");
        } else {
            header("Location: index.php");
        }
        exit;

    } else {
        $erro = "Credenciais inválidas";
    }
}
?>


<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    
    <script src="https://cdn.tailwindcss.com"></script>

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    <style>
        header { background-color: #C1E3D9;}
    </style>
</head>
<body>

    <header>
    <div class="max-w-7xl mx-auto px-6 py-6 flex justify-between items-center"> 
    <h1 class="text-xl font-bold text-green-700 tracking-tight">
        E-Lixo Zero <span class="text-gray-800">Lisboa</span>
      </h1>
    <nav class="space-x-6 text-sm">
        <a href="index.php" class="hover:underline">Inicio</a>
    </nav>
    </div>
  </header>

    <section id="contacto" class="bg-white py-16">
        <div class="max-w-2xl mx-auto px-6">
        <h3 class="text-3xl font-bold mb-6">Login</h3>
        <form class="space-y-4" method="post" action="">
            <input type="email" name="email" placeholder="Email" class="w-full border p-3 rounded" required />
            <input type="password" name="senha" placeholder="Palavra-Passe" class= "w-full border p-3 rounded" required/>
            <button class="bg-green-700 text-white px-6 py-3 rounded hover:bg-green-800">Login</button>
            <p class="text-center text-sm text-gray-600">
                Não tem uma conta?
                <a href="registar.php" class="text-green-700 font-semibold hover:underline">
                    Registre aqui
        </a>
      </p>
        </form>
        </div>
    </section>
    
</body>
</html>