<?php
session_start();
require "connectdb.php";

if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: index.php");
    exit;
}

$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome = $_POST['nome'];
    $morada = $_POST['morada'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];
    $tipo = $_POST['tipo'];

    $stmt = $pdo->prepare("
        INSERT INTO pontos_recolha (nome, morada, latitude, longitude, tipo)
        VALUES (:nome, :morada, :latitude, :longitude, :tipo)
    ");

    if ($stmt->execute([
        ':nome' => $nome,
        ':morada' => $morada,
        ':latitude' => $latitude,
        ':longitude' => $longitude,
        ':tipo' => $tipo
    ])) {
        $mensagem = "Ponto adicionado com sucesso!";
    } else {
        $mensagem = "Erro ao adicionar ponto.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <script src="https://cdn.tailwindcss.com"></script>

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    <style>
        header { background-color: #C1E3D9;}
    </style>

</head>
<body>

    <header>
    <div class="max-w-7xl mx-auto px-6 py-6 flex justify-between items-center"> 
    <h1 class="text-xl font-bold text-green-700 tracking-tight">
        E-Lixo Zero <span class="text-gray-800">Lisboa</span>
      </h1>
    <nav class="space-x-6 text-sm">
        <a href="index.php" class="hover:underline">Inicio</a>
    </nav>
    </div>
  </header>

  <div class="max-w-2xl mx-auto mt-10 bg-white p-6 rounded shadow">
    <h2 class="text-2xl font-bold mb-4">Adicionar Ponto de Recolha</h2>

    <?php if ($mensagem): ?>
        <div class="bg-green-100 text-green-700 p-3 rounded mb-4">
            <?= $mensagem ?>
        </div>
    <?php endif; ?>

    <form method="POST" class="space-y-4">
        <input type="text" name="nome" placeholder="Nome do Local" class="w-full border p-3 rounded" required>
        <input type="text" name="morada" placeholder="Morada" class="w-full border p-3 rounded" required>
        <input type="text" name="latitude" placeholder="Latitude" class="w-full border p-3 rounded" required>
        <input type="text" name="longitude" placeholder="Longitude" class="w-full border p-3 rounded" required>
        
        <select name="tipo" class="w-full border p-3 rounded" required>
            <option value="REEE">REEE</option>
            <option value="Pilhas">Pilhas</option>
            <option value="Ecocentro">Ecocentro</option>
        </select>

        <button class="bg-green-700 text-white px-6 py-3 rounded">
            Adicionar
        </button>
    </form>
  </div>
    
</body>
</html>