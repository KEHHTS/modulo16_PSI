<!DOCTYPE html>
<html lang="pt-PT">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sobre | E-Lixo Zero Lisboa</title>

  <script src="https://cdn.tailwindcss.com"></script>

  <style>
    body {
      font-family: 'Inter', sans-serif;
    }

    /* ANIMAÇÃO */
    .fade-up {
      opacity: 0;
      transform: translateY(50px);
      transition: all 0.8s ease;
    }

    .fade-up.show {
      opacity: 1;
      transform: translateY(0);
    }

    /* DELAY ANIMAÇÃO */
    .delay-1 { transition-delay: 0.2s; }
    .delay-2 { transition-delay: 0.4s; }
    .delay-3 { transition-delay: 0.6s; }

    /* CARD */
    .card-hover {
      transition: all 0.4s ease;
    }

    .card-hover:hover {
      transform: translateY(-10px);
      box-shadow: 0 25px 50px rgba(0,0,0,0.1);
    }

    /* IMAGEM OVERLAY */
    .img-wrap {
      position: relative;
      overflow: hidden;
      border-radius: 16px;
    }

    .img-wrap img {
      width: 100%;
      height: 230px;
      object-fit: cover;
      transition: transform 0.6s ease;
    }

    .img-wrap:hover img {
      transform: scale(1.1);
    }

    .overlay {
      position: absolute;
      inset: 0;
      background: rgba(0,0,0,0.4);
      opacity: 0;
      transition: 0.4s;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: bold;
    }

    .img-wrap:hover .overlay {
      opacity: 1;
    }

    /* BOTÃO */
    .btn {
      transition: all 0.3s ease;
    }

    .btn:hover {
      transform: scale(1.07);
    }

    header { background-color: #C1E3D9;}

    .hero-bg {
      background: linear-gradient(to right, rgba(16,185,129,0.9), rgba(5,150,105,0.9)),
      url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSeoA1ZqCc26zN4W_p3HjWJV1jUa57luXS26Q&');
      background-size: cover;
      background-position: center;
    }

  </style>
</head>

<body class="bg-gray-50 text-gray-800">

<!-- NAVBAR -->
<header>
    <div class="max-w-7xl mx-auto px-6 py-6 flex justify-between items-center"> 
    <h1 class="text-xl font-bold text-green-700 tracking-tight">
        E-Lixo Zero <span class="text-gray-800">Lisboa</span>
      </h1>
    <nav class="space-x-6 text-sm">
        <a href="index.php" class="hover:underline">Inicio</a>
    </nav>
    </div>
  </header>

<!-- HERO -->
<section class="hero-bg text-white py-32 text-center fade-up">
  <h2 class="text-5xl font-bold mb-6">Tecnologia ao serviço do ambiente 🌍</h2>
  <p class="text-green-100">Reciclar nunca foi tão simples</p>
</section>

<!-- SOBRE -->
<section class="py-20 text-center fade-up">
  <h3 class="text-3xl font-bold mb-6">O Propósito</h3>
  <p class="max-w-3xl mx-auto text-gray-600 mb-6">
    Sabemos que nem sempre é fácil saber onde deixar aquele telemóvel antigo ou eletrodoméstico avariado. A nossa plataforma mapeia de forma inteligente todos os pontos de recolha de REEE (Resíduos de Equipamentos Elétricos e Eletrónicos) na área metropolitana de Lisboa.
  </p>
  <p class="max-w-3xl mx-auto text-gray-600">
    O nosso objetivo é eliminar as barreiras entre o descarte e o destino correto, oferecendo informações atualizadas sobre horários, localizações e tipos de resíduos aceites em cada ponto de entrega.
  </p>
</section>

<!-- ESTATÍSTICAS -->
<section class="py-16 bg-white">
  <div class="max-w-6xl mx-auto px-6 grid md:grid-cols-3 gap-8 text-center">

    <div class="fade-up">
      <h4 class="text-4xl font-bold text-green-600 counter" data-target="858">0</h4>
      <p class="text-gray-600 font-medium">Pontos Mapeados em Lisboa</p>
      <p class="text-xs text-gray-400 mt-1">Verificados pela nossa equipa</p>
    </div>

    <div class="fade-up delay-1">
      <h4 class="text-4xl font-bold text-green-600 counter" data-target="24">0</h4>
      <p class="text-gray-600 font-medium">Freguesias Mapeadas</p>
      <p class="text-xs text-gray-400 mt-1">Cobertura da rede em Lisboa</p>
    </div>

    <div class="fade-up delay-2">
      <h4 class="text-4xl font-bold text-green-600 counter" data-target="250">0</h4>
      <p class="text-gray-600 font-medium">kg de Resíduos Encaminhados</p>
      <p class="text-xs text-gray-400 mt-1">Estimativa de impacto do projeto</p>
    </div>

  </div>
</section>

<!-- COMO AJUDAMOS -->
<section class="py-24">
  <div class="max-w-7xl mx-auto px-6">

    <div class="text-center mb-16 fade-up">
      <h3 class="text-4xl font-bold">Como ajudamos?</h3>
      <div class="w-16 h-1 bg-green-600 mx-auto mt-4"></div>
    </div>

    <div class="grid md:grid-cols-3 gap-10">

      <div class="fade-up card-hover">
  <div class="img-wrap">
    <img src="https://images.unsplash.com/photo-1559027615-cd4628902d4a">
    <div class="overlay">Educação</div>
  </div>
  <h4 class="mt-4 font-bold">01. Informar</h4>
  <p class="text-sm text-gray-600 leading-relaxed">
    Educamos os cidadãos sobre a importância da reciclagem de resíduos eletrónicos,
    explicando os impactos ambientais do descarte incorreto e incentivando práticas mais conscientes.
  </p>
</div>

<div class="fade-up delay-1 card-hover">
  <div class="img-wrap">
    <img src="https://images.unsplash.com/photo-1469474968028-56623f02e42e">
    <div class="overlay">Sustentabilidade</div>
  </div>
  <h4 class="mt-4 font-bold">02. Facilitar</h4>
  <p class="text-sm text-gray-600 leading-relaxed">
    Através de um mapa interativo, permitimos que qualquer utilizador encontre rapidamente
    o ponto de recolha mais próximo, tornando o processo de reciclagem simples, rápido e acessível.
  </p>
</div>

<div class="fade-up delay-2 card-hover">
  <div class="img-wrap">
    <img src="https://tnb.studio/storage/blog/marketing-de-comunidade-o-que-e-e-como-usar-na-estrategia-digital.jpeg">
    <div class="overlay">Comunidade</div>
  </div>
  <h4 class="mt-4 font-bold">03. Envolver</h4>
  <p class="text-sm text-gray-600 leading-relaxed">
    Incentivamos a participação ativa da comunidade, permitindo que os utilizadores
    adicionem novos pontos de recolha e contribuam para a melhoria contínua da plataforma.
  </p>
</div>

    </div>

  </div>
</section>

<!-- CTA -->
<section class="py-24 bg-green-600 text-white text-center fade-up">
  <h3 class="text-3xl font-bold mb-4">Começa hoje 🚀</h3>
  <a href="mapa.html" class="bg-white text-green-700 px-8 py-3 rounded-xl btn">
    Ver Mapa
  </a>
</section>

<!-- SCRIPT -->
<script>
  const elements = document.querySelectorAll('.fade-up');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if(entry.isIntersecting){
        entry.target.classList.add('show');
      }
    });
  });

  elements.forEach(el => observer.observe(el));

  // CONTADOR
  const counters = document.querySelectorAll('.counter');

  counters.forEach(counter => {
    const update = () => {
      const target = +counter.getAttribute('data-target');
      const count = +counter.innerText;

      const increment = target / 100;

      if(count < target){
        counter.innerText = Math.ceil(count + increment);
        setTimeout(update, 20);
      } else {
        counter.innerText = target;
      }
    };

    update();
  });
</script>

</body>
</html>