import sys
import smtplib
from email.mime.text import MIMEText

# argumentos vindos do PHP
nome = sys.argv[1]
email_destino = sys.argv[2]

# configuração do email
remetente = "elixo@gmail.com"
senha = "gsrv ypzp dfbq ievw"

assunto = "Conta criada com sucesso"
mensagem = f"""
Olá {nome},

A sua conta foi criada com sucesso no sistema E-Lixo Zero Lisboa.

Obrigado!
"""

msg = MIMEText(mensagem)
msg["Subject"] = assunto
msg["From"] = remetente
msg["To"] = email_destino

# envio
try:
    servidor = smtplib.SMTP("smtp.gmail.com", 587)
    servidor.starttls()
    servidor.login(remetente, senha)
    servidor.send_message(msg)
    servidor.quit()
except Exception as e:
    print("Erro:", e)