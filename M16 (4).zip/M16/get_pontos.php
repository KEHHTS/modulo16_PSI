<?php
require 'connectdb.php';

$stmt = $pdo->query("SELECT * FROM locais");
$pontos = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($pontos);
?>