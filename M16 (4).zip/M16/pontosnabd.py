import json
import mysql.connector

conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="bdm16",
)

cursor = conn.cursor()

with open("Pilhoes.json", encoding="utf-8") as f:
    data = json.load(f)

for feature in data["features"]:
    
    props = feature["properties"]
    coords = feature["geometry"]["coordinates"]

    sql = """ 
    INSERT INTO locais
    (objectid, cod_sig, idtipo, tprs_id, tprs_desc, freguesia, rua, local_nome, produtor, longitude, latitude)
    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """

    valores = (
        props["OBJECTID"],
        props["COD_SIG"],
        props["IDTIPO"],
        props["TPRS_ID"],
        props["TPRS_DESC"],
        props["FRE_AB"],
        props["TOP_MOD_1"],
        props["PRSL_LOCAL"],
        props["PRODUTOR"],
        coords[0],
        coords[1]
    )
    cursor.execute(sql, valores)
conn.commit()