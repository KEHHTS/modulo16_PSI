<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <script src="https://cdn.tailwindcss.com"></script>

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    <style>
        header { background-color: #C1E3D9;}
    </style>

</head>
<body>

    <header>
    <div class="max-w-7xl mx-auto px-6 py-6 flex justify-between items-center"> 
    <h1 class="text-xl font-bold text-green-700 tracking-tight">
        E-Lixo Zero <span class="text-gray-800">Lisboa</span>
      </h1>
    <nav class="space-x-6 text-sm">
        <a href="index.php" class="hover:underline">Inicio</a>
    </nav>
    </div>
  </header>
    
</body>
</html>