<?php
require "connectdb.php";

$erro = "";
$sucesso = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $tipo = $_POST['tipo'];

    if (!$nome || !$email || !$senha || !$tipo) {
        $erro = "Preencha os campos obrigatórios";
    } else {

        $check = $pdo->prepare("SELECT id FROM utilizador WHERE email = :email");
        $check->execute([':email' => $email]);

        if ($check->rowCount() > 0) {
            $erro = "Email já registado";
        } else {

            $hash = password_hash($senha, PASSWORD_DEFAULT);

            $stmt = $pdo->prepare(
                "INSERT INTO utilizador (nome, email, senha, tipo) 
                VALUES 
                (:nome, :email, :senha, :tipo)
            ");

            $stmt->execute([
                ':nome' => $nome,
                ':email' => $email,
                ':senha' => $hash,
                ':tipo' => $tipo
            ]);

            $sucesso = "Utilizador registado com sucesso";
        }
    }
}




?>

<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    
    <script src="https://cdn.tailwindcss.com"></script>

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    <style>
        header { background-color: #C1E3D9;}
    </style>

</head>
<body>

    <header>
    <div class="max-w-7xl mx-auto px-6 py-6 flex justify-between items-center"> 
    <h1 class="text-xl font-bold text-green-700 tracking-tight">
        E-Lixo Zero <span class="text-gray-800">Lisboa</span>
      </h1>
    <nav class="space-x-6 text-sm">
        <a href="index.php" class="hover:underline">Inicio</a>
    </nav>
    </div>
  </header>

    <section id="contacto" class="bg-white py-16">
  <div class="max-w-md mx-auto px-6">
    
    <h3 class="text-3xl font-bold mb-8 text-center">Criar Conta</h3>

    <form method="post" action="" class="space-y-5">

      <!-- Nome -->
      <div>
        <label for="nome" class="block text-sm font-medium mb-1">Nome</label>
        <input
          id="nome"
          name="nome"
          type="text"
          placeholder="Seu nome completo"
          autocomplete="name"
          required
          class="w-full border border-gray-300 p-3 rounded-lg focus:ring-2 focus:ring-green-600 focus:border-green-600 outline-none"
        />
      </div>

      <!-- Email -->
      <div>
        <label for="email" class="block text-sm font-medium mb-1">Email</label>
        <input
          id="email"
          name="email"
          type="email"
          placeholder="seuemail@exemplo.com"
          autocomplete="email"
          required
          class="w-full border border-gray-300 p-3 rounded-lg focus:ring-2 focus:ring-green-600 focus:border-green-600 outline-none"
        />
      </div>

      <!-- Palavra-passe -->
      <div>
        <label for="senha" class="block text-sm font-medium mb-1">Palavra-passe</label>
        <input
          id="senha"
          name="senha"
          type="password"
          placeholder="Mínimo 6 caracteres"
          minlength="6"
          required
          class="w-full border border-gray-300 p-3 rounded-lg focus:ring-2 focus:ring-green-600 focus:border-green-600 outline-none"
        />
      </div>

      <!-- Tipo de utilizador -->
      <div>
        <label for="tipo" class="block text-sm font-medium mb-1">Tipo de conta</label>
        <select
          id="tipo"
          name="tipo"
          required
          class="w-full border border-gray-300 p-3 rounded-lg bg-white focus:ring-2 focus:ring-green-600 focus:border-green-600 outline-none"
        >
          <option value="" disabled selected>Selecione uma opção</option>
          <option value="utilizador">Utilizador</option>
          <option value="admin">Administrador</option>
        </select>
      </div>

      <!-- Botão -->
      <button
        type="submit"
        class="w-full bg-green-700 text-white py-3 rounded-lg font-semibold hover:bg-green-800 transition"
      >
        Criar Conta
      </button>

    </form>
  </div>
</section>

</body>
</html>